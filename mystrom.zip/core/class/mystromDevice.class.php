<?php

/**
 * Represents a mystrom device
 */
class MyStromDevice
{
    public $id = '';
    public $name = '';
    public $type = '';
    public $daylyConsumption = '';
    public $monthlyConsumption = '';
    public $state = '';
    public $power = '';
}
