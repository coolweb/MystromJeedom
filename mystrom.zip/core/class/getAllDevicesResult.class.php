<?php

/**
 * Result from get all devices
 */
class GetAllDevicesResult extends MyStromApiResult
{
    public $devices = array();
}
