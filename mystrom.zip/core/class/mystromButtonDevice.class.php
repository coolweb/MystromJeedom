<?php

/**
 * Entity class for mystrom wifi button.
 */
class MystromButtonDevice
{
    public $macAddress = '';
    public $ipAddress = '';
    public $singleUrl ='';
    public $doubleUrl = '';
    public $longUrl = '';
    public $touchedUrl = '';
}
