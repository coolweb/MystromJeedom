<?php

/**
 * A result from an http call to the mystrom api
 */
class MyStromApiResult
{
    public $status = '';
    public $error = '';
}
